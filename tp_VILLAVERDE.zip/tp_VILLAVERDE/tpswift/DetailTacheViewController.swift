//
//  DetailTacheViewController.swift
//  tpswift
//
//  Created by Lucas Villaverde on 14/12/2021.
//

import UIKit

class DetailTacheViewController: UIViewController {
    

    
    @IBOutlet weak var DetailTitreTache: UILabel!
    @IBOutlet weak var DetailDescriptionTache: UILabel!
    @IBOutlet weak var DetailDateTache: UILabel!
    
    //Variable de type tache qui va recuperer les infos
    var data : Tache?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Bordure description
        DetailDescriptionTache.layer.borderWidth = 1.0
        DetailDescriptionTache.layer.cornerRadius = 8
        
        if let tache = data{
            //recuperation des infos
            DetailTitreTache.text = tache.getTitre()
            DetailDescriptionTache.text = tache.getDescription()
            DetailDateTache.text =  tache.DateToString()
        }
        else{
            DetailTitreTache.text = ""
            DetailDescriptionTache.text = "Problème de recuperation des données"
            DetailDateTache.text = ""
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? ModifierTacheViewController {
                vc.data = data
            }
        }
    
    //permet de sauvegarder un changement
    @IBAction func save(_ unwindSegue: UIStoryboardSegue) {
        if let vc = unwindSegue.source as? ModifierTacheViewController {
            if let majTache = vc.data {
                DetailTitreTache.text = majTache.getTitre()
                DetailDescriptionTache.text = majTache.getDescription()
                DetailDateTache.text = majTache.DateToString()
                data?.setTitre(titre: majTache.getTitre())
                data?.setDescription(description: majTache.getDescription())
                data?.setDate(date: majTache.getDate())
            }
        }
    }
    
    //permet d'annuler un changement
    @IBAction func cancel(_ unwindSegue: UIStoryboardSegue){
        if let vc = unwindSegue.source as? ModifierTacheViewController{
            vc.dismiss(animated: true, completion: nil)
        }
    }
}
    
