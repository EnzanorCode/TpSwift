//
//  AjoutTacheViewController.swift
//  tpswift
//
//  Created by Lucas Villaverde on 14/12/2021.
//

import UIKit

class AjoutTacheViewController: UIViewController, UITextFieldDelegate {
    var data = Tache(titre: "titre", description: "description", date: Date())

    @IBOutlet weak var titreTache: UITextField!
    @IBOutlet weak var dateTache: UIDatePicker!
    @IBOutlet weak var descriptionTache: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        titreTache.text = "Ajouter un titre"
        descriptionTache.text = "Ajouter une description ici"
        dateTache.date = Date()
        
        titreTache.delegate = self
        descriptionTache.delegate = self
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        data.setTitre(titre: titreTache.text!)
        data.setDescription(description: descriptionTache.text!)
        return true
    }
    
    @IBAction func MajDatePicker(_ sender: UIDatePicker) {
        data.setDate(date: dateTache.date)
    }
}
