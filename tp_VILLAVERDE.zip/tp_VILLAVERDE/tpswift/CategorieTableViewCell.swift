//
//  CategorieTableViewCell.swift
//  tpswift
//
//  Created by Lucas Villaverde on 14/12/2021.
//

import UIKit

class CategorieTableViewCell: UITableViewCell {

    @IBOutlet weak var titreCategorie: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
