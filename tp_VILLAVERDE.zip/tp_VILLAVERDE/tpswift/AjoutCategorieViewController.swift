//
//  AjoutCategorieViewController.swift
//  tpswift
//
//  Created by Lucas Villaverde on 14/12/2021.
//

import UIKit

class AjoutCategorieViewController: UIViewController, UITextFieldDelegate {

    var newCategorie = ""
    @IBOutlet weak var titreCategorie: UITextField!
   
    override func viewDidLoad() {
        super.viewDidLoad()

        titreCategorie.text = "Nouvelle categorie"
        titreCategorie.delegate = self
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        newCategorie = titreCategorie.text!
        return true
    }

}
