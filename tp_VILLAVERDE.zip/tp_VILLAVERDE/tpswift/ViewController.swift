//
//  ViewController.swift
//  tpswift
//
//  Created by Lucas Villaverde on 14/12/2021.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {

    @IBOutlet weak var tableauCategorie: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listeCategorie.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     
        let cell = tableView.dequeueReusableCell(withIdentifier:"celluleCategorie", for: indexPath) as! CategorieTableViewCell
        let row = indexPath.row
        cell.titreCategorie.text = listeCategorie[row].getCategorie()
        return cell
    }
    
    var listeCategorie: [ListeTaches] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        initialiser()
        tableauCategorie.dataSource = self
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? ListeTacheViewController {
            let row = tableauCategorie.indexPathForSelectedRow!.row
            vc.listeTache = listeCategorie[row]
        }
    }

    @IBAction func save(_ unwindSegue: UIStoryboardSegue) {
        if let vc = unwindSegue.source as? AjoutCategorieViewController{
            let newliste = ListeTaches(categorie: vc.newCategorie)
            listeCategorie.append(newliste)
            tableauCategorie.reloadData()
        }
    }
    
    func initialiser(){ //Creation des taches et des categories statiquement au lancement de l'appli
        
        //Creation des dates
        var component = DateComponents()
        component.year = 2021
        component.month = 12
        component.day = 1
        let userCalendar = Calendar(identifier: .gregorian)
        let date1 = userCalendar.date(from: component)
        var component2 = DateComponents()
        component2.month = 11
        component2.year = 2021
        component2.day = 15
        let date2 = userCalendar.date(from: component2)
        var component3 = DateComponents()
        component3.month = 11
        component3.year = 2023
        component3.day = 17
        component3.hour = 10
        let date3 = userCalendar.date(from: component3)
        var component4 = DateComponents()
        component4.month = 1
        component4.year = 2022
        component4.day = 9
        component4.hour = 22
        let date4 = userCalendar.date(from: component4)
        
        //Creation des taches
        let todo1 = Tache(titre: "Course",description: "Riz, haricot rouge, viande haché, epices, bière", date: date1!)
        let todo2 = Tache(titre: "Football",description: "Pas oblier de mettre les bieres au frais ", date:date2!)
        let todo3 = Tache(titre: "Postuler",description: "Candidater chez cisco sur Linkedin", date: date3!)
        let todo4 = Tache(titre: "Swift",description: "Rendre le TP de swift", date: date4!)
        
        //Creation des catégories
        let categorie1 = ListeTaches(categorie: "General")
        categorie1.ajouterTache(tache: todo1)
        categorie1.ajouterTache(tache: todo2)
        categorie1.ajouterTache(tache: todo3)
        let categorie2 = ListeTaches(categorie: "Cours")
        categorie2.ajouterTache(tache: todo4)
        
        //Ajout des categories a la liste des catégories
        listeCategorie.append(categorie1)
        listeCategorie.append(categorie2)
        
    }
}

