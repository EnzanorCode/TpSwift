//
//  Tache.swift
//  tpswift
//
//  Created by Lucas Villaverde on 14/12/2021.
//

import Foundation

class Tache {
    
    var _titre:String
    var _description:String
    var _date:Date
    var _etat:String
    
    init(titre:String, description:String, date:Date){
        _titre = titre
        _description = description
        _date = date
        _etat = "□"
    }
    
    //getters
    func getTitre() -> String {
        return _titre
    }
    
    func getDescription() -> String {
        return _description
    }
    
    func getDate() -> Date {
        return _date
    }
    
    func getEtat() -> String {
        return _etat
    }
    
    func setTitre(titre:String){
        _titre = titre
    }
    
    //setters
    func setDescription(description:String){
        _description = description
    }
    
    func setDate(date:Date){
        _date = date
    }
    
    func setEtat(etat:String){
        _etat = etat
    }
    
    //convertie une date en String selon le format "dd/MM/yyyy HH:mm"
    func DateToString() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy HH:mm"
        let date = formatter.string(from: self.getDate())
        return date
    }
}
