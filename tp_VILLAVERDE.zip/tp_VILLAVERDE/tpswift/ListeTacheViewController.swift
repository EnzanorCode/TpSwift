//
//  ListeTacheViewController.swift
//  tpswift
//
//  Created by Lucas Villaverde on 14/12/2021.
//

import UIKit

class ListeTacheViewController: UIViewController, UITableViewDataSource {

    
    @IBOutlet weak var tableauTache: UITableView!
    
    var listeTache: ListeTaches?
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return listeTache!.getListeTaches().count
        }
        
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            listeTache!.triDate()
            let cell = tableView.dequeueReusableCell(withIdentifier:"celluleTache", for: indexPath) as! TacheTableViewCell
            let row = indexPath.row
            cell.titreTache.text = listeTache!.getListeTaches()[row].getTitre()
            cell.dateTache.text = listeTache!.getListeTaches()[row].DateToString()
            cell.etatTache.setTitle(listeTache!.getListeTaches()[row].getEtat(), for: .normal)
            cell.etatTache.tag = row
            return cell
        }
        
        
        
        override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view.
            
            
            
            tableauTache.dataSource = self
        }
        
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if let vc = segue.destination as? DetailTacheViewController {
                let row = tableauTache.indexPathForSelectedRow!.row
                vc.data = listeTache!.getListeTaches()[row]
            }
        }
         
        @IBAction func sauvegarder(_ unwindSegue: UIStoryboardSegue) {
            if let vc = unwindSegue.source as? AjoutTacheViewController{
                listeTache!.ajouterTache(tache: vc.data)
                tableauTache.reloadData()
            }
        }
        
        @IBAction func supprimer(_ unwindSegue: UIStoryboardSegue) {
            if let vc = unwindSegue.source as? DetailTacheViewController{
                listeTache!.supprimerTache(tache: vc.data!)
                tableauTache.reloadData()
            }
        }
        
        override func viewWillAppear(_ animated: Bool) {
            super.viewWillAppear(animated)
            tableauTache.reloadData()
        }
        
        
        @IBAction func majEtat(_ sender: UIButton) {
            let row = sender.tag
            
            if listeTache!.getListeTaches()[row].getEtat() == "☑" {
                listeTache!.getListeTaches()[row].setEtat(etat: "□")
            }
            else {
                listeTache!.getListeTaches()[row].setEtat(etat: "☑")
            }
            tableauTache.reloadData()
        }
        

}
