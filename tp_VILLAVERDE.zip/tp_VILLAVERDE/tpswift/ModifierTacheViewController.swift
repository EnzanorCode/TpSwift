//
//  ModifierTacheViewController.swift
//  tpswift
//
//  Created by Lucas Villaverde on 14/12/2021.
//

import UIKit

class ModifierTacheViewController: UIViewController, UITextFieldDelegate {


    @IBOutlet weak var nouveauTitre: UITextField!
    @IBOutlet weak var nouvelleDescription: UITextField!
    @IBOutlet weak var nouvelleDate: UIDatePicker!
    
    var data : Tache?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let tache = data {
            nouveauTitre.text = tache.getTitre()
            nouvelleDescription.text = tache.getDescription()
            nouvelleDate.date = tache.getDate()
        }
        nouveauTitre.delegate = self
        nouvelleDescription.delegate = self
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        data!.setTitre(titre: nouveauTitre.text!)
        data!.setDescription(description: nouvelleDescription.text!)
        return true
    }
    
    
    @IBAction func MajDatePicker(_ sender: UIDatePicker) {
        data!.setDate(date: nouvelleDate.date)
    }
}
