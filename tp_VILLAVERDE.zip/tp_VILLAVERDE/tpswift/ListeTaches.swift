//
//  ListeTaches.swift
//  tpswift
//
//  Created by Lucas Villaverde on 14/12/2021.
//

import Foundation

class ListeTaches{
    
    var _categorie:String
    var _listeTaches = [Tache]()
    
    init(categorie:String){
        _categorie = categorie
    }
    
    //getters
    func getCategorie() -> String{
        return _categorie
    }
    
    func getListeTaches() -> [Tache]{
        return _listeTaches
    }
    
    //ajoute une tache au tableau
    func ajouterTache(tache:Tache){
        _listeTaches.append(tache)
    }
    
    //fonction qui tri les dates
    func triDate(){
        _listeTaches.sort(by :{ $0.getDate().compare($1.getDate()) == .orderedAscending })
    }
    
    //fonctions qui permet de supprimer une tache
    func supprimerTache(tache:Tache){
        var index = 0
        var i = 0
        for y in _listeTaches{
            if (tache.getTitre() == y.getTitre()) && (tache.getDescription() == y.getDescription()){
                index = i
            }
            i = i + 1
        }
        _listeTaches.remove(at: index)
    }
    
    
}
